/* ============================================================================
   AI STUDENT IMPACT - CLEANING, VALIDATION AND ANALYSIS
   ----------------------------------------------------------------------------
   SQL dialect      : PostgreSQL (syntax also verified on DuckDB).
                      Dialect-specific: PERCENTILE_CONT ... WITHIN GROUP,
                      CREATE OR REPLACE VIEW, ::NUMERIC casts, FILTER clause.
   Staging table    : stg_ai_student_impact  (must be loaded BEFORE running)
   Source file      : ai_student_impact_dataset.csv (50,000 rows, 16 columns)
   Object changes   : Creates ONLY views (vw_*). No DROP/DELETE/UPDATE of data.
   Load example     : \copy stg_ai_student_impact FROM 'ai_student_impact_dataset.csv' CSV HEADER

   CLEANING ASSUMPTIONS (same as the Python script and the Excel workbook)
     1. Raw data had no NULLs, no duplicate rows and no duplicate Student_ID,
        so no rows are removed. Row count before = row count after.
     2. Text labels are TRIMmed (no-op on this file, kept for reuse).
     3. Paid_Subscription (boolean) is shown as 'Yes'/'No'.
     4. Derived: GPA_Change = Post - Pre GPA; GenAI usage band from
        Weekly_GenAI_Hours; GPA ceiling flag (Post GPA >= 4.0).
     5. Ceiling (GPA = 4.0) and cap (hours = 40) values are legitimate
        observations: FLAGGED, never removed.
   ============================================================================ */


/* ============================================================================
   SECTION 1. STAGING TABLE
   ============================================================================ */
CREATE TABLE IF NOT EXISTS stg_ai_student_impact (
    Student_ID                  INTEGER,
    Major_Category              VARCHAR(50),
    Year_of_Study               VARCHAR(50),
    Pre_Semester_GPA            NUMERIC(5,3),
    Weekly_GenAI_Hours          NUMERIC(6,2),
    Primary_Use_Case            VARCHAR(50),
    Prompt_Engineering_Skill    VARCHAR(50),
    Tool_Diversity              INTEGER,
    Paid_Subscription           BOOLEAN,
    Traditional_Study_Hours     NUMERIC(6,2),
    Perceived_AI_Dependency     INTEGER,
    Institutional_Policy        VARCHAR(50),
    Anxiety_Level_During_Exams  INTEGER,
    Post_Semester_GPA           NUMERIC(5,3),
    Skill_Retention_Score       NUMERIC(6,2),
    Burnout_Risk_Level          VARCHAR(50)
);


/* ============================================================================
   SECTION 2. PROFILING
   ============================================================================ */
-- 2.1 Shape and key uniqueness
SELECT COUNT(*)                         AS total_rows,
       COUNT(DISTINCT Student_ID)       AS distinct_ids,
       MIN(Student_ID)                  AS min_id,
       MAX(Student_ID)                  AS max_id
FROM stg_ai_student_impact;

-- 2.2 Numeric profile
SELECT 'Pre_Semester_GPA' AS column_name, MIN(Pre_Semester_GPA) AS min_v, AVG(Pre_Semester_GPA) AS avg_v, MAX(Pre_Semester_GPA) AS max_v FROM stg_ai_student_impact
UNION ALL SELECT 'Post_Semester_GPA', MIN(Post_Semester_GPA), AVG(Post_Semester_GPA), MAX(Post_Semester_GPA) FROM stg_ai_student_impact
UNION ALL SELECT 'Weekly_GenAI_Hours', MIN(Weekly_GenAI_Hours), AVG(Weekly_GenAI_Hours), MAX(Weekly_GenAI_Hours) FROM stg_ai_student_impact
UNION ALL SELECT 'Traditional_Study_Hours', MIN(Traditional_Study_Hours), AVG(Traditional_Study_Hours), MAX(Traditional_Study_Hours) FROM stg_ai_student_impact
UNION ALL SELECT 'Perceived_AI_Dependency', MIN(Perceived_AI_Dependency), AVG(Perceived_AI_Dependency), MAX(Perceived_AI_Dependency) FROM stg_ai_student_impact
UNION ALL SELECT 'Anxiety_Level_During_Exams', MIN(Anxiety_Level_During_Exams), AVG(Anxiety_Level_During_Exams), MAX(Anxiety_Level_During_Exams) FROM stg_ai_student_impact
UNION ALL SELECT 'Skill_Retention_Score', MIN(Skill_Retention_Score), AVG(Skill_Retention_Score), MAX(Skill_Retention_Score) FROM stg_ai_student_impact;

-- 2.3 Category inventories (look for inconsistent labels)
SELECT 'Major_Category' AS column_name, Major_Category AS label, COUNT(*) AS n FROM stg_ai_student_impact GROUP BY Major_Category
UNION ALL SELECT 'Year_of_Study', Year_of_Study, COUNT(*) FROM stg_ai_student_impact GROUP BY Year_of_Study
UNION ALL SELECT 'Primary_Use_Case', Primary_Use_Case, COUNT(*) FROM stg_ai_student_impact GROUP BY Primary_Use_Case
UNION ALL SELECT 'Prompt_Engineering_Skill', Prompt_Engineering_Skill, COUNT(*) FROM stg_ai_student_impact GROUP BY Prompt_Engineering_Skill
UNION ALL SELECT 'Institutional_Policy', Institutional_Policy, COUNT(*) FROM stg_ai_student_impact GROUP BY Institutional_Policy
UNION ALL SELECT 'Burnout_Risk_Level', Burnout_Risk_Level, COUNT(*) FROM stg_ai_student_impact GROUP BY Burnout_Risk_Level
ORDER BY 1, 2;


/* ============================================================================
   SECTION 3. DATA-QUALITY VALIDATION ENGINE  (PASS / WARN / FAIL)
   ============================================================================ */
WITH t AS (SELECT COUNT(*) AS n FROM stg_ai_student_impact),
checks AS (
    SELECT 'Row count' AS check_name, 'volume' AS check_type,
           (SELECT n FROM t) AS actual_value, '> 0' AS expected_condition,
           CASE WHEN (SELECT n FROM t) > 0 THEN 'PASS' ELSE 'FAIL' END AS status, 'high' AS severity
    UNION ALL
    SELECT 'Duplicate Student_ID', 'uniqueness',
           (SELECT COUNT(*) - COUNT(DISTINCT Student_ID) FROM stg_ai_student_impact), '0',
           CASE WHEN (SELECT COUNT(*) - COUNT(DISTINCT Student_ID) FROM stg_ai_student_impact) = 0 THEN 'PASS' ELSE 'FAIL' END, 'high'
    UNION ALL
    SELECT 'Fully duplicated rows', 'uniqueness',
           (SELECT COUNT(*) FROM (SELECT 1 FROM stg_ai_student_impact GROUP BY Student_ID, Major_Category, Year_of_Study, Pre_Semester_GPA, Weekly_GenAI_Hours, Primary_Use_Case, Prompt_Engineering_Skill, Tool_Diversity, Paid_Subscription, Traditional_Study_Hours, Perceived_AI_Dependency, Institutional_Policy, Anxiety_Level_During_Exams, Post_Semester_GPA, Skill_Retention_Score, Burnout_Risk_Level HAVING COUNT(*) > 1) d),
           '0',
           CASE WHEN (SELECT COUNT(*) FROM (SELECT 1 FROM stg_ai_student_impact GROUP BY Student_ID, Major_Category, Year_of_Study, Pre_Semester_GPA, Weekly_GenAI_Hours, Primary_Use_Case, Prompt_Engineering_Skill, Tool_Diversity, Paid_Subscription, Traditional_Study_Hours, Perceived_AI_Dependency, Institutional_Policy, Anxiety_Level_During_Exams, Post_Semester_GPA, Skill_Retention_Score, Burnout_Risk_Level HAVING COUNT(*) > 1) d) = 0 THEN 'PASS' ELSE 'WARN' END, 'medium'
    UNION ALL
    SELECT 'NULL / blank cells (all columns)', 'completeness',
           (SELECT SUM(
                (CASE WHEN Student_ID IS NULL THEN 1 ELSE 0 END)
              + (CASE WHEN Major_Category IS NULL OR TRIM(Major_Category) = '' THEN 1 ELSE 0 END)
              + (CASE WHEN Year_of_Study IS NULL OR TRIM(Year_of_Study) = '' THEN 1 ELSE 0 END)
              + (CASE WHEN Pre_Semester_GPA IS NULL THEN 1 ELSE 0 END)
              + (CASE WHEN Weekly_GenAI_Hours IS NULL THEN 1 ELSE 0 END)
              + (CASE WHEN Primary_Use_Case IS NULL OR TRIM(Primary_Use_Case) = '' THEN 1 ELSE 0 END)
              + (CASE WHEN Prompt_Engineering_Skill IS NULL OR TRIM(Prompt_Engineering_Skill) = '' THEN 1 ELSE 0 END)
              + (CASE WHEN Tool_Diversity IS NULL THEN 1 ELSE 0 END)
              + (CASE WHEN Paid_Subscription IS NULL THEN 1 ELSE 0 END)
              + (CASE WHEN Traditional_Study_Hours IS NULL THEN 1 ELSE 0 END)
              + (CASE WHEN Perceived_AI_Dependency IS NULL THEN 1 ELSE 0 END)
              + (CASE WHEN Institutional_Policy IS NULL OR TRIM(Institutional_Policy) = '' THEN 1 ELSE 0 END)
              + (CASE WHEN Anxiety_Level_During_Exams IS NULL THEN 1 ELSE 0 END)
              + (CASE WHEN Post_Semester_GPA IS NULL THEN 1 ELSE 0 END)
              + (CASE WHEN Skill_Retention_Score IS NULL THEN 1 ELSE 0 END)
              + (CASE WHEN Burnout_Risk_Level IS NULL OR TRIM(Burnout_Risk_Level) = '' THEN 1 ELSE 0 END))
            FROM stg_ai_student_impact),
           '0',
           'REVIEW', 'medium'
    UNION ALL
    SELECT 'GPA outside 0-4 (pre or post)', 'range',
           (SELECT COUNT(*) FROM stg_ai_student_impact WHERE Pre_Semester_GPA NOT BETWEEN 0 AND 4 OR Post_Semester_GPA NOT BETWEEN 0 AND 4),
           '0', 'REVIEW', 'high'
    UNION ALL
    SELECT 'Weekly_GenAI_Hours outside 0-168', 'range',
           (SELECT COUNT(*) FROM stg_ai_student_impact WHERE Weekly_GenAI_Hours NOT BETWEEN 0 AND 168),
           '0', 'REVIEW', 'high'
    UNION ALL
    SELECT 'Traditional_Study_Hours outside 0-168', 'range',
           (SELECT COUNT(*) FROM stg_ai_student_impact WHERE Traditional_Study_Hours NOT BETWEEN 0 AND 168),
           '0', 'REVIEW', 'high'
    UNION ALL
    SELECT 'Tool_Diversity outside 1-5', 'range',
           (SELECT COUNT(*) FROM stg_ai_student_impact WHERE Tool_Diversity NOT BETWEEN 1 AND 5),
           '0', 'REVIEW', 'high'
    UNION ALL
    SELECT 'Dependency / Anxiety outside 1-10', 'range',
           (SELECT COUNT(*) FROM stg_ai_student_impact WHERE Perceived_AI_Dependency NOT BETWEEN 1 AND 10 OR Anxiety_Level_During_Exams NOT BETWEEN 1 AND 10),
           '0', 'REVIEW', 'high'
    UNION ALL
    SELECT 'Skill_Retention_Score outside 0-100', 'range',
           (SELECT COUNT(*) FROM stg_ai_student_impact WHERE Skill_Retention_Score NOT BETWEEN 0 AND 100),
           '0', 'REVIEW', 'high'
    UNION ALL
    SELECT 'Labels with leading/trailing spaces', 'consistency',
           (SELECT COUNT(*) FROM stg_ai_student_impact
             WHERE Major_Category <> TRIM(Major_Category) OR Year_of_Study <> TRIM(Year_of_Study)
                OR Primary_Use_Case <> TRIM(Primary_Use_Case) OR Prompt_Engineering_Skill <> TRIM(Prompt_Engineering_Skill)
                OR Institutional_Policy <> TRIM(Institutional_Policy) OR Burnout_Risk_Level <> TRIM(Burnout_Risk_Level)),
           '0', 'REVIEW', 'low'
    UNION ALL
    SELECT 'Unexpected Burnout_Risk_Level label', 'domain',
           (SELECT COUNT(*) FROM stg_ai_student_impact WHERE Burnout_Risk_Level NOT IN ('Low','Medium','High')),
           '0', 'REVIEW', 'medium'
    UNION ALL
    SELECT 'Post GPA at 4.0 ceiling (informational)', 'distribution',
           (SELECT COUNT(*) FROM stg_ai_student_impact WHERE Post_Semester_GPA >= 4.0),
           'informational: limits measurable GPA gain', 'INFO', 'low'
    UNION ALL
    SELECT 'Weekly_GenAI_Hours at 40 h cap (informational)', 'distribution',
           (SELECT COUNT(*) FROM stg_ai_student_impact WHERE Weekly_GenAI_Hours >= 40),
           'informational: possible top-coding', 'INFO', 'low'
)
-- Rules marked REVIEW pass when actual_value = 0; INFO rows are never failures.
SELECT check_name, check_type, actual_value, expected_condition,
       CASE WHEN status = 'REVIEW' THEN CASE WHEN actual_value = 0 THEN 'PASS' ELSE 'FAIL' END
            WHEN status = 'INFO'   THEN CASE WHEN actual_value = 0 THEN 'PASS' ELSE 'WARN' END
            ELSE status END AS status,
       severity
FROM checks;


/* ============================================================================
   SECTION 4. CLEANING + CLEAN ANALYTICAL VIEW
   ============================================================================ */
CREATE OR REPLACE VIEW vw_ai_student_clean AS
SELECT
    Student_ID,
    TRIM(Major_Category)                              AS Major_Category,
    TRIM(Year_of_Study)                               AS Year_of_Study,
    Pre_Semester_GPA,
    Weekly_GenAI_Hours,
    TRIM(Primary_Use_Case)                            AS Primary_Use_Case,
    TRIM(Prompt_Engineering_Skill)                    AS Prompt_Engineering_Skill,
    Tool_Diversity,
    CASE WHEN Paid_Subscription THEN 'Yes' ELSE 'No' END AS Paid_Subscription,
    Traditional_Study_Hours,
    Perceived_AI_Dependency,
    TRIM(Institutional_Policy)                        AS Institutional_Policy,
    Anxiety_Level_During_Exams,
    Post_Semester_GPA,
    Skill_Retention_Score,
    TRIM(Burnout_Risk_Level)                          AS Burnout_Risk_Level,
    -- derived columns (same definitions as Python / Excel)
    ROUND(Post_Semester_GPA - Pre_Semester_GPA, 3)    AS GPA_Change,
    CASE WHEN Weekly_GenAI_Hours <= 0  THEN '0 h'
         WHEN Weekly_GenAI_Hours <= 2  THEN '0-2 h'
         WHEN Weekly_GenAI_Hours <= 5  THEN '2-5 h'
         WHEN Weekly_GenAI_Hours <= 10 THEN '5-10 h'
         WHEN Weekly_GenAI_Hours <= 20 THEN '10-20 h'
         ELSE '20+ h' END                             AS GenAI_Usage_Band,
    CASE WHEN Post_Semester_GPA >= 4.0 THEN 1 ELSE 0 END AS GPA_Ceiling_Flag
FROM stg_ai_student_impact
WHERE Student_ID IS NOT NULL;   -- no rows are dropped on this dataset (see Section 8)


/* ============================================================================
   SECTION 5. KPI SUMMARY
   ============================================================================ */
SELECT COUNT(*)                                                        AS students,
       ROUND(AVG(Pre_Semester_GPA), 3)                                 AS avg_pre_gpa,
       ROUND(AVG(Post_Semester_GPA), 3)                                AS avg_post_gpa,
       ROUND(AVG(GPA_Change), 3)                                       AS avg_gpa_change,
       ROUND(AVG(CASE WHEN GPA_Change > 0 THEN 1.0 ELSE 0 END), 4)     AS pct_gpa_improved,
       ROUND(AVG(Weekly_GenAI_Hours), 2)                               AS avg_weekly_genai_hours,
       ROUND(AVG(Traditional_Study_Hours), 2)                          AS avg_traditional_hours,
       ROUND(AVG(Skill_Retention_Score), 2)                            AS avg_skill_retention,
       ROUND(AVG(Anxiety_Level_During_Exams), 2)                       AS avg_exam_anxiety,
       ROUND(AVG(Perceived_AI_Dependency), 2)                          AS avg_ai_dependency,
       ROUND(AVG(CASE WHEN Burnout_Risk_Level = 'High' THEN 1.0 ELSE 0 END), 4) AS pct_high_burnout,
       ROUND(AVG(CASE WHEN Paid_Subscription = 'Yes' THEN 1.0 ELSE 0 END), 4)   AS pct_paid
FROM vw_ai_student_clean;


/* ============================================================================
   SECTION 6. SEGMENT ANALYSIS
   Reusable pattern: one query per dimension, same measures, NULLIF-guarded.
   ============================================================================ */
-- 6.1 By weekly GenAI usage band (key relationship in the data)
SELECT GenAI_Usage_Band,
       COUNT(*)                                                             AS students,
       ROUND(100.0 * COUNT(*) / NULLIF(SUM(COUNT(*)) OVER (), 0), 2)        AS pct_of_students,
       ROUND(AVG(GPA_Change), 3)                                            AS avg_gpa_change,
       ROUND(AVG(Skill_Retention_Score), 2)                                 AS avg_retention,
       ROUND(AVG(Anxiety_Level_During_Exams), 2)                            AS avg_anxiety,
       ROUND(AVG(Perceived_AI_Dependency), 2)                               AS avg_dependency,
       ROUND(AVG(Traditional_Study_Hours), 2)                               AS avg_traditional_hours,
       ROUND(100.0 * COUNT(*) FILTER (WHERE Burnout_Risk_Level = 'High') / NULLIF(COUNT(*), 0), 1) AS pct_high_burnout
FROM vw_ai_student_clean
GROUP BY GenAI_Usage_Band
ORDER BY MIN(Weekly_GenAI_Hours);

-- 6.2 By major
SELECT Major_Category, COUNT(*) AS students,
       ROUND(AVG(Weekly_GenAI_Hours), 2)   AS avg_genai_hours,
       ROUND(AVG(GPA_Change), 3)           AS avg_gpa_change,
       ROUND(AVG(Skill_Retention_Score), 2) AS avg_retention,
       ROUND(AVG(Perceived_AI_Dependency), 2) AS avg_dependency
FROM vw_ai_student_clean GROUP BY Major_Category ORDER BY avg_genai_hours DESC;

-- 6.3 By year of study
SELECT Year_of_Study, COUNT(*) AS students,
       ROUND(AVG(GPA_Change), 3) AS avg_gpa_change,
       ROUND(AVG(Skill_Retention_Score), 2) AS avg_retention
FROM vw_ai_student_clean GROUP BY Year_of_Study ORDER BY avg_gpa_change DESC;

-- 6.4 By primary use case
SELECT Primary_Use_Case, COUNT(*) AS students,
       ROUND(AVG(GPA_Change), 3) AS avg_gpa_change,
       ROUND(AVG(Skill_Retention_Score), 2) AS avg_retention
FROM vw_ai_student_clean GROUP BY Primary_Use_Case ORDER BY avg_gpa_change DESC;

-- 6.5 By prompt-engineering skill
SELECT Prompt_Engineering_Skill, COUNT(*) AS students,
       ROUND(AVG(GPA_Change), 3) AS avg_gpa_change,
       ROUND(AVG(Skill_Retention_Score), 2) AS avg_retention
FROM vw_ai_student_clean GROUP BY Prompt_Engineering_Skill ORDER BY avg_retention DESC;

-- 6.6 By institutional policy
SELECT Institutional_Policy, COUNT(*) AS students,
       ROUND(AVG(Anxiety_Level_During_Exams), 2) AS avg_anxiety,
       ROUND(AVG(GPA_Change), 3) AS avg_gpa_change,
       ROUND(AVG(Skill_Retention_Score), 2) AS avg_retention
FROM vw_ai_student_clean GROUP BY Institutional_Policy ORDER BY avg_anxiety DESC;

-- 6.7 By tool diversity
SELECT Tool_Diversity, COUNT(*) AS students,
       ROUND(AVG(GPA_Change), 3) AS avg_gpa_change,
       ROUND(AVG(Skill_Retention_Score), 2) AS avg_retention
FROM vw_ai_student_clean GROUP BY Tool_Diversity ORDER BY Tool_Diversity;

-- 6.8 Burnout distribution
SELECT Burnout_Risk_Level, COUNT(*) AS students,
       ROUND(100.0 * COUNT(*) / NULLIF(SUM(COUNT(*)) OVER (), 0), 2) AS pct_of_students,
       ROUND(AVG(Weekly_GenAI_Hours), 2) AS avg_genai_hours,
       ROUND(AVG(Perceived_AI_Dependency), 2) AS avg_dependency
FROM vw_ai_student_clean GROUP BY Burnout_Risk_Level
ORDER BY CASE Burnout_Risk_Level WHEN 'Low' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END;


/* ============================================================================
   SECTION 7. ADVANCED ANALYSIS
   ============================================================================ */
-- 7.1 Major x Prompt skill: ranked by GPA change (window ranking, tie-safe)
WITH seg AS (
    SELECT Major_Category, Prompt_Engineering_Skill, COUNT(*) AS students,
           AVG(GPA_Change) AS avg_gpa_change
    FROM vw_ai_student_clean
    GROUP BY Major_Category, Prompt_Engineering_Skill
)
SELECT Major_Category, Prompt_Engineering_Skill, students,
       ROUND(avg_gpa_change, 3) AS avg_gpa_change,
       DENSE_RANK() OVER (ORDER BY avg_gpa_change DESC) AS rank_overall,
       DENSE_RANK() OVER (PARTITION BY Major_Category ORDER BY avg_gpa_change DESC) AS rank_in_major
FROM seg
ORDER BY rank_overall;

-- 7.2 IQR outlier counts (flag only; rows are kept)
WITH q AS (
    SELECT PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY Weekly_GenAI_Hours) AS q1,
           PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY Weekly_GenAI_Hours) AS q3
    FROM vw_ai_student_clean
)
SELECT 'Weekly_GenAI_Hours' AS variable,
       q.q1, q.q3,
       q.q3 + 1.5 * (q.q3 - q.q1) AS upper_fence,
       (SELECT COUNT(*) FROM vw_ai_student_clean c
         WHERE c.Weekly_GenAI_Hours > q.q3 + 1.5 * (q.q3 - q.q1)) AS rows_above_fence
FROM q;

-- 7.3 Correlations with GPA_Change (CORR returns NULL on zero variance)
SELECT ROUND(CORR(Traditional_Study_Hours, GPA_Change)::NUMERIC, 3)      AS corr_trad_hours_vs_change,
       ROUND(CORR(Tool_Diversity, GPA_Change)::NUMERIC, 3)               AS corr_tool_div_vs_change,
       ROUND(CORR(Weekly_GenAI_Hours, GPA_Change)::NUMERIC, 3)           AS corr_genai_hours_vs_change,
       ROUND(CORR(Pre_Semester_GPA, GPA_Change)::NUMERIC, 3)             AS corr_pre_gpa_vs_change,
       ROUND(CORR(Weekly_GenAI_Hours, Perceived_AI_Dependency)::NUMERIC, 3) AS corr_hours_vs_dependency,
       ROUND(CORR(Weekly_GenAI_Hours, Skill_Retention_Score)::NUMERIC, 3)   AS corr_hours_vs_retention,
       ROUND(CORR(Pre_Semester_GPA, Post_Semester_GPA)::NUMERIC, 3)         AS corr_pre_vs_post_gpa
FROM vw_ai_student_clean;

-- 7.4 Heavy users (20+ h/week) vs the rest, same measures
SELECT CASE WHEN Weekly_GenAI_Hours > 20 THEN 'Heavy (20+ h)' ELSE 'Other' END AS user_group,
       COUNT(*) AS students,
       ROUND(AVG(GPA_Change), 3) AS avg_gpa_change,
       ROUND(AVG(Skill_Retention_Score), 2) AS avg_retention,
       ROUND(AVG(Anxiety_Level_During_Exams), 2) AS avg_anxiety,
       ROUND(100.0 * COUNT(*) FILTER (WHERE Burnout_Risk_Level = 'High') / NULLIF(COUNT(*), 0), 1) AS pct_high_burnout
FROM vw_ai_student_clean
GROUP BY CASE WHEN Weekly_GenAI_Hours > 20 THEN 'Heavy (20+ h)' ELSE 'Other' END;

-- 7.5 Ceiling-effect check: GPA change among students NOT at the 4.0 ceiling
SELECT GenAI_Usage_Band,
       COUNT(*) AS students_below_ceiling,
       ROUND(AVG(GPA_Change), 3) AS avg_gpa_change_excl_ceiling
FROM vw_ai_student_clean
WHERE GPA_Ceiling_Flag = 0
GROUP BY GenAI_Usage_Band
ORDER BY MIN(Weekly_GenAI_Hours);


/* ============================================================================
   SECTION 8. FINAL QC / RECONCILIATION (staging vs clean view)
   ============================================================================ */
SELECT 'Row count'            AS metric,
       (SELECT COUNT(*) FROM stg_ai_student_impact)::NUMERIC AS staging_value,
       (SELECT COUNT(*) FROM vw_ai_student_clean)::NUMERIC   AS clean_value
UNION ALL
SELECT 'Distinct Student_ID',
       (SELECT COUNT(DISTINCT Student_ID) FROM stg_ai_student_impact),
       (SELECT COUNT(DISTINCT Student_ID) FROM vw_ai_student_clean)
UNION ALL
SELECT 'Sum Weekly_GenAI_Hours',
       (SELECT SUM(Weekly_GenAI_Hours) FROM stg_ai_student_impact),
       (SELECT SUM(Weekly_GenAI_Hours) FROM vw_ai_student_clean)
UNION ALL
SELECT 'Sum Post_Semester_GPA',
       (SELECT SUM(Post_Semester_GPA) FROM stg_ai_student_impact),
       (SELECT SUM(Post_Semester_GPA) FROM vw_ai_student_clean)
UNION ALL
SELECT 'Count High burnout',
       (SELECT COUNT(*) FROM stg_ai_student_impact WHERE Burnout_Risk_Level = 'High'),
       (SELECT COUNT(*) FROM vw_ai_student_clean   WHERE Burnout_Risk_Level = 'High');

-- Reconciliation verdict: every metric must match between layers.
WITH r AS (
    SELECT (SELECT COUNT(*) FROM stg_ai_student_impact) AS s_rows,
           (SELECT COUNT(*) FROM vw_ai_student_clean)   AS c_rows,
           (SELECT SUM(Post_Semester_GPA) FROM stg_ai_student_impact) AS s_gpa,
           (SELECT SUM(Post_Semester_GPA) FROM vw_ai_student_clean)   AS c_gpa
)
SELECT CASE WHEN s_rows = c_rows AND s_gpa = c_gpa THEN 'PASS' ELSE 'FAIL' END AS reconciliation_status,
       s_rows - c_rows AS rows_removed_by_cleaning
FROM r;
