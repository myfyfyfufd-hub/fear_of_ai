#!/usr/bin/env python3
"""
AI Student Impact - Cleaning, Validation, EDA and KPI script
=============================================================
Usage:
    python ai_student_impact_analysis.py [path_to_csv] [output_dir]

Defaults:
    path_to_csv = ai_student_impact_dataset.csv  (same folder)
    output_dir  = ./analysis_output

Source columns (16): Student_ID, Major_Category, Year_of_Study, Pre_Semester_GPA,
Weekly_GenAI_Hours, Primary_Use_Case, Prompt_Engineering_Skill, Tool_Diversity,
Paid_Subscription, Traditional_Study_Hours, Perceived_AI_Dependency,
Institutional_Policy, Anxiety_Level_During_Exams, Post_Semester_GPA,
Skill_Retention_Score, Burnout_Risk_Level

Outputs (written to output_dir):
    cleaned_data.csv, data_quality_checks.csv, kpis.csv,
    segment_*.csv, correlations.csv, outliers_flagged.csv, charts/*.png
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# ----------------------------------------------------------------------------
# 1. LOAD
# ----------------------------------------------------------------------------
src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("ai_student_impact_dataset.csv")
out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("analysis_output")
out.mkdir(parents=True, exist_ok=True)
(out / "charts").mkdir(exist_ok=True)

raw = pd.read_csv(src)
df = raw.copy()
print(f"Loaded {len(raw):,} rows x {raw.shape[1]} columns from {src}")

CAT_COLS = ["Major_Category", "Year_of_Study", "Primary_Use_Case",
            "Prompt_Engineering_Skill", "Institutional_Policy", "Burnout_Risk_Level"]
NUM_COLS = ["Pre_Semester_GPA", "Weekly_GenAI_Hours", "Tool_Diversity",
            "Traditional_Study_Hours", "Perceived_AI_Dependency",
            "Anxiety_Level_During_Exams", "Post_Semester_GPA", "Skill_Retention_Score"]

# ----------------------------------------------------------------------------
# 2. INSPECTION
# ----------------------------------------------------------------------------
print("\n--- Dtypes ---")
print(raw.dtypes)
print("\n--- Missing values ---")
print(raw.isna().sum()[lambda s: s > 0] if raw.isna().any().any() else "None")

# ----------------------------------------------------------------------------
# 3. CLEANING
# Decisions are based on what the data showed: no nulls, no duplicates, labels
# already consistent. Cleaning is therefore limited to safe standardisation.
# ----------------------------------------------------------------------------
# 3a. Trim whitespace in text columns (no-op here, kept for reproducibility).
for c in CAT_COLS:
    df[c] = df[c].astype(str).str.strip()

# 3b. Paid_Subscription: boolean -> "Yes"/"No" so it filters like any category.
df["Paid_Subscription"] = df["Paid_Subscription"].map({True: "Yes", False: "No"})

# 3c. Duplicates: flag, do not silently drop.
dup_rows = int(df.duplicated().sum())
dup_ids = int(df["Student_ID"].duplicated().sum())

# 3d. Derived analysis columns.
df["GPA_Change"] = (df["Post_Semester_GPA"] - df["Pre_Semester_GPA"]).round(3)
bins = [-0.001, 0, 2, 5, 10, 20, np.inf]
labels = ["0 h", "0-2 h", "2-5 h", "5-10 h", "10-20 h", "20+ h"]
df["GenAI_Usage_Band"] = pd.cut(df["Weekly_GenAI_Hours"], bins=bins, labels=labels)
df["GPA_Ceiling_Flag"] = (df["Post_Semester_GPA"] >= 4.0).astype(int)  # capped at 4.0

# ----------------------------------------------------------------------------
# 4. VALIDATION (PASS / WARN / FAIL)
# ----------------------------------------------------------------------------
checks = []

def add(name, ctype, actual, expected, status, severity):
    checks.append(dict(check_name=name, check_type=ctype, actual_value=actual,
                       expected_condition=expected, status=status, severity=severity))

add("Row count", "volume", len(df), ">0", "PASS" if len(df) > 0 else "FAIL", "high")
add("Fully duplicated rows", "uniqueness", dup_rows, "0", "PASS" if dup_rows == 0 else "WARN", "medium")
add("Duplicate Student_ID", "uniqueness", dup_ids, "0", "PASS" if dup_ids == 0 else "FAIL", "high")
add("Total null cells", "completeness", int(raw.isna().sum().sum()), "0",
    "PASS" if raw.isna().sum().sum() == 0 else "WARN", "medium")

range_rules = {
    "Pre_Semester_GPA": (0, 4), "Post_Semester_GPA": (0, 4),
    "Weekly_GenAI_Hours": (0, 168), "Traditional_Study_Hours": (0, 168),
    "Tool_Diversity": (1, 5), "Perceived_AI_Dependency": (1, 10),
    "Anxiety_Level_During_Exams": (1, 10), "Skill_Retention_Score": (0, 100),
}
for col, (lo, hi) in range_rules.items():
    bad = int(((df[col] < lo) | (df[col] > hi)).sum())
    add(f"{col} within [{lo},{hi}]", "range", bad, "0 out-of-range",
        "PASS" if bad == 0 else "FAIL", "high")

# Ceiling / cap effects (informational; legitimate observations, not errors).
n_ceiling = int(df["GPA_Ceiling_Flag"].sum())
add("Post GPA at 4.0 ceiling", "distribution", n_ceiling,
    "informational (limits measurable GPA gain)", "WARN" if n_ceiling else "PASS", "low")
n_cap = int((df["Weekly_GenAI_Hours"] >= 40).sum())
add("Weekly_GenAI_Hours at 40 h cap", "distribution", n_cap,
    "informational (possible top-coding)", "WARN" if n_cap else "PASS", "low")

dq = pd.DataFrame(checks)
dq.to_csv(out / "data_quality_checks.csv", index=False)
print("\n--- Data-quality checks ---")
print(dq.to_string(index=False))

# ----------------------------------------------------------------------------
# 5. OUTLIERS (IQR rule, flagged only - never deleted)
# ----------------------------------------------------------------------------
flag_frames = []
for c in ["Weekly_GenAI_Hours", "Traditional_Study_Hours", "GPA_Change", "Skill_Retention_Score"]:
    q1, q3 = df[c].quantile([0.25, 0.75])
    iqr = q3 - q1
    lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    m = (df[c] < lo) | (df[c] > hi)
    print(f"Outliers {c}: {int(m.sum()):,} outside [{lo:.2f}, {hi:.2f}]")
    flag_frames.append(df.loc[m, ["Student_ID", c]].assign(variable=c, lower=lo, upper=hi)
                       .rename(columns={c: "value"}))
pd.concat(flag_frames).to_csv(out / "outliers_flagged.csv", index=False)

# ----------------------------------------------------------------------------
# 6. EDA + KPIs
# ----------------------------------------------------------------------------
kpis = {
    "Students": len(df),
    "Avg Pre GPA": df["Pre_Semester_GPA"].mean(),
    "Avg Post GPA": df["Post_Semester_GPA"].mean(),
    "Avg GPA Change": df["GPA_Change"].mean(),
    "% GPA Improved": (df["GPA_Change"] > 0).mean(),
    "Avg Weekly GenAI Hours": df["Weekly_GenAI_Hours"].mean(),
    "Avg Traditional Study Hours": df["Traditional_Study_Hours"].mean(),
    "Avg Skill Retention": df["Skill_Retention_Score"].mean(),
    "Avg Exam Anxiety": df["Anxiety_Level_During_Exams"].mean(),
    "Avg AI Dependency": df["Perceived_AI_Dependency"].mean(),
    "% High Burnout": (df["Burnout_Risk_Level"] == "High").mean(),
    "% Paid Subscription": (df["Paid_Subscription"] == "Yes").mean(),
}
pd.Series(kpis, name="value").to_csv(out / "kpis.csv", header=True)
print("\n--- KPIs ---")
for k, v in kpis.items():
    print(f"{k:32s} {v:,.3f}")


def segment(col):
    g = df.groupby(col, observed=True)
    t = g.agg(students=("Student_ID", "size"),
              avg_genai_hours=("Weekly_GenAI_Hours", "mean"),
              avg_pre_gpa=("Pre_Semester_GPA", "mean"),
              avg_post_gpa=("Post_Semester_GPA", "mean"),
              avg_gpa_change=("GPA_Change", "mean"),
              avg_retention=("Skill_Retention_Score", "mean"),
              avg_anxiety=("Anxiety_Level_During_Exams", "mean"),
              avg_dependency=("Perceived_AI_Dependency", "mean"),
              pct_high_burnout=("Burnout_Risk_Level", lambda s: (s == "High").mean()))
    return t.round(3)


for col in ["GenAI_Usage_Band", "Major_Category", "Year_of_Study", "Primary_Use_Case",
            "Prompt_Engineering_Skill", "Institutional_Policy", "Burnout_Risk_Level",
            "Paid_Subscription", "Tool_Diversity"]:
    seg = segment(col)
    seg.to_csv(out / f"segment_{col}.csv")
    print(f"\n--- By {col} ---")
    print(seg.to_string())

corr = df[NUM_COLS + ["GPA_Change"]].corr().round(3)
corr.to_csv(out / "correlations.csv")
print("\n--- Key correlations with GPA_Change ---")
print(corr["GPA_Change"].drop("GPA_Change").sort_values(ascending=False))

# ----------------------------------------------------------------------------
# 7. CHARTS (optional - skipped if matplotlib is missing)
# ----------------------------------------------------------------------------
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    def bar(series, title, fname, ylabel):
        fig, ax = plt.subplots(figsize=(7, 4))
        series.plot(kind="bar", ax=ax, color="#2F5D8A")
        ax.set_title(title); ax.set_ylabel(ylabel); ax.set_xlabel("")
        plt.xticks(rotation=30, ha="right"); plt.tight_layout()
        fig.savefig(out / "charts" / fname, dpi=130); plt.close(fig)

    bar(segment("GenAI_Usage_Band")["avg_gpa_change"], "Avg GPA change by weekly GenAI hours",
        "gpa_change_by_usage.png", "GPA change")
    bar(segment("GenAI_Usage_Band")["pct_high_burnout"], "% High burnout by weekly GenAI hours",
        "burnout_by_usage.png", "share High")
    bar(segment("Prompt_Engineering_Skill")["avg_retention"], "Skill retention by prompt skill",
        "retention_by_skill.png", "retention score")
    bar(segment("Primary_Use_Case")["avg_gpa_change"], "Avg GPA change by primary use case",
        "gpa_change_by_use_case.png", "GPA change")
except ImportError:
    print("matplotlib not installed - charts skipped")

# ----------------------------------------------------------------------------
# 8. EXPORT
# ----------------------------------------------------------------------------
df.to_csv(out / "cleaned_data.csv", index=False)
print(f"\nCleaned rows: {len(df):,} (raw {len(raw):,}). Outputs saved to {out.resolve()}")
